package org.example.registropaciente;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import org.example.registropaciente.dao.PacienteDAD;

public class PacienteController {

    PacienteDAD pacientes = new PacienteDAD();

    @FXML
    private TextField txtnombres;
    @FXML
    private TextField txtapellidos;
    @FXML
    private Label lblContador;
    @FXML
    protected void agregarOnclick() {
        leerDatos();
        cantidadPaciente();
        limpiarCampos();
    }

    private void leerDatos(){
        String nombres = txtnombres.getText();
        String apellidos = txtapellidos.getText();
        Paciente paciente = new Paciente(nombres, apellidos);

}
    private void AgregarOnClick(){
        leerDatos();
        cantidadPaciente();
        limpiarCampos();
    }
    private void cantidadPaciente() {
        lblContador.setText(String.valueOf(pacientes.listarPacientes().size()));
    }

    private void limpiarCampos() {
        txtnombres.setText("");
        txtapellidos.setText("");
        txtnombres.requestFocus();

    }
}

